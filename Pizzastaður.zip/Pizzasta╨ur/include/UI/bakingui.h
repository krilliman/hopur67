#ifndef BAKINGUI_H
#define BAKINGUI_H


class bakingui
{
    public:
        bakingui();

        void startUI();

    protected:

    private:
};

#endif // BAKINGUI_H
