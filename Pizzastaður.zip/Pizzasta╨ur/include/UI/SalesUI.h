#ifndef SALESUI_H
#define SALESUI_H


class SalesUI
{
    public:
        SalesUI();
        void startUI();

    private:
};

#endif // SALESUI_H
