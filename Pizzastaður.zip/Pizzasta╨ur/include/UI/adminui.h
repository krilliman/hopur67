#ifndef ADMINUI_H
#define ADMINUI_H


class AdminUI
{
    public:
        AdminUI();
        virtual ~AdminUI();

        void startUI();
    protected:

    private:
};

#endif // ADMINUI_H
