#ifndef DELIVERYUI_H
#define DELIVERYUI_H


class deliveryui
{
    public:
        deliveryui();
        void startUI();
    private:
};

#endif // DELIVERYUI_H
